import pygame
import sys
from pygame.locals import *

pygame.init()

sw = 800
sh = 800

win = pygame.display.set_mode((sw, sh))
pygame.display.set_caption('Draf 4 - Scrolling Background with Player')

bg = pygame.image.load('espaco.png').convert()
bg = pygame.transform.scale(bg, (sw, sh))
bgWidth, bgHeight = bg.get_rect().size

# Até onde o player pode se mover?
stageWidth = bgWidth * 2
stageHeight = bgHeight * 2
stagePosX = 0
stagePosY = 0

startScrollingPosX = bgWidth / 2
startScrollingPosY = bgHeight / 2

circleRadius = 25
circlePosX = circleRadius
circlePosY = sh // 2

playerPosX = sw // 2
playerPosY = sh // 2
playerVelocityX = 0
playerVelocityY = 0

clock = pygame.time.Clock()

fps = 500

run = True

while run:

    keys = pygame.key.get_pressed()

    for evento in pygame.event.get():
        if evento.type == QUIT:
            run = False
    if keys[K_ESCAPE]:
        run = False

    if keys[K_RIGHT]:
        playerVelocityX = 1
    elif keys[K_LEFT]:
        playerVelocityX = -1
    elif keys[K_UP]:
        playerVelocityY = -1
    elif keys[K_DOWN]:
        playerVelocityY = 1
    else:
        playerVelocityX = 0
        playerVelocityY = 0

    playerPosX += playerVelocityX
    playerPosY += playerVelocityY

    if playerPosX > stageWidth - circleRadius:
        playerPosX = stageWidth - circleRadius
    if playerPosX < circleRadius:
        playerPosX = circleRadius
    if playerPosX < startScrollingPosX:
        circlePosX = playerPosX
    elif playerPosX > stageWidth - startScrollingPosX:
        circlePosX = playerPosX - stageWidth + sw
    else:
        circlePosX = startScrollingPosX
        stagePosX += -playerVelocityX

    rel_x = stagePosX % bgWidth
    win.blit(bg, (rel_x - bgWidth, 0))
    if rel_x < sw:
        win.blit(bg, (rel_x, 0))

    pygame.draw.circle(win, (255, 255, 255), (circlePosX, circlePosY), circleRadius, 0)

    pygame.display.update()

    win.blit(bg, (0, 0))

    clock.tick(fps)

pygame.quit()
