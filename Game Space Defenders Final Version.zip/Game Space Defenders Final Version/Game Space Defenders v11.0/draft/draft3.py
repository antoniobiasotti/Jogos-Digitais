import pygame
import random
from pygame.locals import *

pygame.init()

sw = 650
sh = 650

screen = pygame.display.set_mode((sw, sh))
pygame.display.set_caption('Draft 3')

pygame.mixer.music.load('music.mp3')
pygame.mixer.music.set_volume(0.1)
pygame.mixer.music.play(-1)
music = True

#menu_bg = pygame.image.load('menu.png').convert_alpha()
#menu_bg = pygame.transform.scale(menu_bg, (sw, sh))

game_bg = pygame.image.load('espaco.png').convert_alpha()
game_bg = pygame.transform.scale(game_bg, (sw, sh))

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.img = 'nave.png'
        self.surf = pygame.image.load('nave.png').convert_alpha()
        self.surf = pygame.transform.scale(self.surf, (80, 80))
        self.rect = self.surf.get_rect()
        self.rect_player = self.surf.get_rect()
        self.rect_player.x = 450
        self.rect_player.y = 500
        self.head = ()

    #Movimento
    def update(self, tecla, mouse, click):
        if tecla[K_UP]:
            self.rect.move_ip(0, -8)
        if tecla[K_DOWN]:
            self.rect.move_ip(0, 8)
        if tecla[K_LEFT]:
            self.rect.move_ip(-8, 0)
        if tecla[K_RIGHT]:
            self.rect.move_ip(8, 0)
        drag = 0
        if click[0] == 1 and self.rect.x + 90 > mouse[0] > self.rect.x and self.rect.y + 90 > mouse[
            1] > self.rect.y:
            drag = 1
        if click[0] == 0:
            drag = 0
        if drag == 1:
            self.rect.x = mouse[0] - 25
            self.rect.y = mouse[1] - 25

        #Constrain
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > sw:
            self.rect.right = sw
        elif self.rect.top <= 0:
            self.rect.top = 0
        elif self.rect.bottom >= 650:
            self.rect.bottom = 650

class Asteroid(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.surf = pygame.image.load(('meteoro.png')).convert_alpha()
        self.surf = pygame.transform.scale(self.surf, (50, 50))
        self.rect = self.surf.get_rect(
            center=(
                random.randint(sw + 20, sw + 100),
                random.randint(0, 650),
            )
        )
        self.speed = random.randint(5, 20)

    def update(self):
        self.rect.move_ip(-self.speed, 0)
        if self.rect.right < 0:
            self.kill()

class Tiro(object):
    def __init__(self):
        self.point = player.head

class Tempo:
    def __init__(self):
        self.timer = 0
        self.tempo_segundo = 0
        self.fonte = pygame.font.SysFont('Arial Black', 20)
        self.texto = self.fonte.render("Timer: " + str(self.tempo_segundo), True, (0, 0, 0), (255, 255, 255))
        self.pos_texto = self.texto.get_rect()
        self.pos_texto.center = (325, 630)

    def crono(self):
        if self.timer <= 30:
            self.timer += 1
        else:
            self.tempo_segundo += 1
            self.timer = 0
        self.texto = self.fonte.render("Timer: " + str(self.tempo_segundo), True, (0, 0, 0), (255, 255, 255))
        screen.blit(self.texto, self.pos_texto)

#def redrawGameWindow():

ADDASTEROID = pygame.USEREVENT + 1
pygame.time.set_timer(ADDASTEROID, 450)

player = Player()

tempo = Tempo()

asteroids = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()
all_sprites.add(player)

clock = pygame.time.Clock()

run = True

while run:

    clock.tick(30)

    tecla = pygame.key.get_pressed()

    for evento in pygame.event.get():
        if evento.type == QUIT:
            run = False
        elif evento.type == ADDASTEROID:
            new_asteroid = Asteroid()
            asteroids.add(new_asteroid)
            all_sprites.add(new_asteroid)
        elif tecla[K_ESCAPE]:
            run = False
        elif tecla[K_F10]:
            if music:
                pygame.mixer.music.pause()
                music = False
        elif tecla[K_SPACE]:
            atirar = True
        elif evento.type == MOUSEBUTTONDOWN:
            click = 1
        elif evento.type == MOUSEBUTTONUP:
            click = 0

    rel_y = sh % game_bg.get_rect().height
    screen.blit(game_bg, (0, rel_y - game_bg.get_rect().height))
    if rel_y < sh:
        screen.blit(game_bg, (0, rel_y))
    sh += 12

    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    player.update(tecla, mouse, click)

    asteroids.update()

    tempo.crono()

    for entity in all_sprites:
        screen.blit(entity.surf, entity.rect)

    #if pygame.sprite.spritecollideany(player, asteroids):
        #player.kill()
        #run = False

    pygame.display.update()
pygame.quit()

